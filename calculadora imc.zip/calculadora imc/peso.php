<?php
 $peso = $_POST['peso'];
 $altura = $_POST['altura'];
 $imc = $peso / $altura**2;


 if ($imc <16)
     $res = "magreza grave";
elseif ($imc <17)
     $res = "magraza moderada";
elseif ($imc <18.5)
     $res = "magreza leve";
elseif ($imc <25)
     $res = "saudavel";
elseif ($imc <30)
     $res = "sobrepeso";  
elseif ($imc <35)
     $res = "obesidade grau 1"; 
elseif ($imc <40)
     $res = "obesidade grau 2 severa";  
elseif ($imc > 40)
     $res = "obesidade grau 3 morbida";    

echo "$res" ;
?>