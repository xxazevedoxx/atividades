<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login</title>
</head>
<body>
<?php
$nome = $_POST["nome"];
$senha = $_POST["senha"];

if ($nome == "ana" && $senha == "12345") {
  echo "Autenticação realizada com sucesso";
} else {
  echo "Você não tem permissão de visualizar essa página";
}
?>